import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:practiceblogapp/screens/Home.dart';
import 'package:practiceblogapp/screens/LoginRegisterPage.dart';
import 'package:practiceblogapp/screens/Register.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  if(kIsWeb){
    await Firebase.initializeApp(
      options: const FirebaseOptions(apiKey: "AIzaSyCEOZaCcaWKfv2sv1QHtI8QeY4mouW4WtQ",
       appId: "1:374448079204:web:06c04609043bec6b8a7a71",
        messagingSenderId: "374448079204", 
        projectId: "practicedemo-96ff4"));
    runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark
      ),
      home: const MyApp(),
    ));

  }
 
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
   return MaterialApp(
    title:'hello',
    home: RegisterPage(),

    
   
   );
  }
}